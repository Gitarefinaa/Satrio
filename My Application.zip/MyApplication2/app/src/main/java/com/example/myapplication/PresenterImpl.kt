package com.example.myapplication

class PresenterImpl : InterfaceMVP.ModelRepoImpl,InterfaceMVP.ViewLogin,InterfaceMVP.ViewUser {
    override fun Login(login : Boolean) {
        TODO("Not yet implemented")
    }
    override fun ListUser() {
        TODO("Not yet implemented")
    }
    override fun LoginModel(email: String, password: String) {
        TODO("Not yet implemented")
    }

}
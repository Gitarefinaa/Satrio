
package com.example.myapplication;// Kotlin
data class ModelUser(
    val name: String,
    val designation: String?
)